# rag_demo 项目流程架构

## 第一步：创建项目骨架

一个项目的第一件事不是写代码，是把目录结构搭好。原因很简单：如果所有代码堆在一个文件里，改一处可能影响全局，排查问题如大海捞针。所以按职责分目录，每个目录只管一件事。

先建这些文件夹（你现在已经有了，但假设从零开始）：

```
rag_demo/
├── api/         # 对外接口层 —— 接收请求、返回响应
├── models/      # 基础设施层 —— 数据库连接、模型实例
├── loader/      # 文档处理层 —— 加载、切割、入库
├── retriever/   # 检索层 —— 查向量库、重排
├── utils/       # 工具层 —— 配置、日志
└── main.py      # 入口
```

每个文件夹下放一个空的 `__init__.py`，让它变成 Python 包，方便跨目录 `import`。

**为什么要先分层而不是先写功能？**

因为 RAG 的链路是确定的：加载文档 → 切割 → 向量化入库 → 用户提问 → 检索 → 重排 → LLM 生成答案。这个流程里每一步都是独立的一环，拆成独立模块后，比如你哪天想换一种切割方式，只改 `document_splitter.py` 就行，其他文件纹丝不动。

---

## 第二步：配置层 `utils/config.py`

任何项目都有几个东西是"写死在代码里不好，但又到处要用"的，比如 API 密钥、模型名称、数据库地址。如果把这些散落在各个文件里，换 API Key 的时候你要翻遍整个项目改十几处，漏一处就炸。

所以第一步真正的代码，一定是建配置中心。

```python
import os
from dotenv import load_dotenv

load_dotenv()  # 从项目根目录的 .env 文件读取变量到系统环境

qwen_model_name = os.getenv("QWEN_MODEL_NAME")
qwen_api_key = os.getenv("QWEN_API_KEY")
qwen_base_url = os.getenv("QWEN_BASE_URL")
```

然后在项目根目录放一个 `.env` 文件：

```
QWEN_MODEL_NAME=qwen-turbo
QWEN_API_KEY=sk-xxxxxxxx
QWEN_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
```

**三个设计决策的解释：**

1. **用 `.env` 而不是写死在代码里**——API Key 是敏感信息。如果写死在代码里，你推 GitHub 的时候就泄露了。`.env` 加进 `.gitignore`，不上传。

2. **用 `os.getenv()` 而不直接读文件**——`.env` 加载后变量进了系统环境，代码里只跟 `os.getenv()` 打交道。好处是线上部署时可以用服务器的环境变量覆盖 `.env`，代码一行不改。

3. **集中管理而非散落各处**——整个项目只有一个地方定义 `qwen_model_name`，其他文件 `from rag_demo.utils.config import qwen_model_name` 即可。改模型名只改一处。

**一个容易踩的坑**：不要用 `flask.cli.load_dotenv`（你原来的代码就是）。`dotenv` 是独立库，跟 Flask 没关系，直接 `from dotenv import load_dotenv` 才对。前者也能用，但哪天卸了 Flask 就报错，依赖关系不干净。

---

## 第三步：模型层 `models/`

配置有了，接下来要把"大模型"和"向量库"这两个外部服务连上。它们都是单例——整个项目只需要一份连接，没必要每次请求都 new 一个新客户端。

### 3.1 大模型客户端 `models/llm.py`

```python
from langchain_openai import ChatOpenAI
from rag_demo.utils.config import qwen_model_name, qwen_api_key, qwen_base_url

qwen_llm = ChatOpenAI(
    model=qwen_model_name,
    api_key=qwen_api_key,
    base_url=qwen_base_url,
    temperature=0.2
)
```

**为什么用 `ChatOpenAI` 而不是通义千问专门的 SDK？**

通义千问提供了 OpenAI 兼容的 API 端点（`/compatible-mode/v1`），这意味着它跟 ChatGPT 的接口格式一模一样。`ChatOpenAI` 是 LangChain 对 OpenAI 协议的标准封装，直接拿来用就行，不用装任何阿里的 SDK。

如果你用的是 Ollama 本地模型，这里就换成 `ChatOllama`；用的是文心一言，换成 `QianfanChatEndpoint`。格式变了但思路不变——暴露一个 `qwen_llm` 对象，上层调用方不关心底层是谁。

**`temperature=0.2` 是什么意思？**

`temperature` 控制回答的随机性，范围 0 到 2。0.2 偏低，意味着模型更保守、更倾向于选概率最高的词，回答会更稳定、更一致。对于 RAG 场景，我们要求答案基于文档事实而不是自由发挥，所以设低一点。如果去做创意写作，就会设到 0.8 以上。

---

### 3.2 向量库客户端 `models/chroma.py`

```python
import os
from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings

HF_HOME = os.getenv("HF_HOME", "")
EMBEDDING_MODEL_DIR = os.path.join(HF_HOME, "hub", "models--BAAI--bge-base-zh-v1.5")

embeddings = HuggingFaceEmbeddings(
    model_name=EMBEDDING_MODEL_DIR,
    model_kwargs={"device": "cpu"},
    encode_kwargs={"normalize_embeddings": True},
)

vectorstore = Chroma(
    host="localhost",
    port=8081,
    embedding_function=embeddings,
    collection_name="rag_demo",
    collection_metadata={"hnsw:space": "cosine"},
)
```

**逐行解释设计原因：**

**`EMBEDDING_MODEL_DIR` 路径拼接**——之前你已经把模型下到了 `D:\huggingface_cache\hub\models--BAAI--bge-base-zh-v1.5`。传本地路径给 LangChain，它就不会去 HuggingFace 官网联网检查，离线秒加载。如果传 `"BAAI/bge-base-zh-v1.5"` 这个字符串，它每次启动都会尝试连网验证，慢不说，断网直接挂。

**`normalize_embeddings=True`**——把向量归一化到长度 1。Chroma 那边配了 `cosine` 距离，余弦相似度的前提就是向量要先归一化，否则算出来的分数没有意义。这一步不做的话，两个语义相近的句子可能算出很低的相似度。

**`hnsw:space: "cosine"`**——指定 Chroma 用余弦距离做向量搜索。这是语义搜索的标准选择。跟欧氏距离相比：余弦只关心方向不关心长度，所以"这篇文档写了 100 字"和"这篇文档写了 1000 字但意思一样"，余弦能判断出来，欧氏距离可能被向量长度误导。

**为什么这里不做 GPU？**

你之前试过，PyTorch 是 CPU 版。但说实话，`bge-base-zh-v1.5` 只有 409MB，4096 个 token 的文本 CPU 推理也就几十毫秒，对个人项目完全够用。真正需要 GPU 的是生成阶段（LLM），但你用了通义千问 API，那个在云端跑，不需要本地算力。

---

这两个文件写完之后，`rag_demo.models.llm.qwen_llm` 和 `rag_demo.models.chroma.vectorstore` 就成了全局可用的基础设施，任何地方 `import` 就行。

---

## 第四步：文档处理层 `loader/`

这是入库链路的三个环节——加载、切割、写入——顺序不能乱，每一步的输出是下一步的输入。

### 4.1 文档加载 `loader/document_loader.py`

```python
from langchain_community.document_loaders import UnstructuredMarkdownLoader
from langchain_mineru import MinerULoader

class DocumentLoader:
    def __init__(self, file_path: str):
        self.file_path = file_path

    def markdown_loader(self):
        md_loader = UnstructuredMarkdownLoader(file_path=self.file_path)
        docs = md_loader.load()
        return docs

    def mineru_loader(self):
        mu_loader = MinerULoader(source=self.file_path)
        docs = mu_loader.load()
        return docs

    def loader(self):
        suffix = self.file_path.split('.')[-1]
        if suffix == 'md':
            return self.markdown_loader()
        elif suffix in ['pdf', 'docx', 'doc']:
            return self.mineru_loader()
        else:
            raise ValueError(f"暂未支持的文件格式: {suffix}")
```

**为什么要做格式判断而不是一个加载器通吃？**

不同文件格式的内部结构完全不同。Markdown 是纯文本加标记符号，直接按行读就行。PDF 里面是二进制流，文字可能分页、分栏、甚至嵌入图片，需要专门的解析器从物理排版里还原出逻辑段落。Word 的 docx 本质是个压缩包，里面塞了一堆 XML。

`UnstructuredMarkdownLoader` 专门处理 Markdown，轻量快速。`MinerULoader` 是阿里出的文档解析工具，能处理 PDF 和 Word，它会识别标题层级、表格、图片描述，还原出结构化的文档。如果用 Markdown 加载器强行读 PDF，读出来全是乱码。

**`load()` 返回的是什么？**

返回 `List[Document]`。`Document` 是 LangChain 的核心数据结构，有两个字段：`page_content` 存文本内容，`metadata` 存来源信息（文件名、页码等）。后面切割、向量化的环节都认这个格式，所以加载器的职责就是把任何格式都统一转成 `Document`。

---

### 4.2 文档切割 `loader/document_splitter.py`

```python
from langchain_text_splitters import RecursiveCharacterTextSplitter

class DocumentSplitter:
    def __init__(self, docs: List[Document]):
        self.docs = docs

    def split(self):
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=512,
            chunk_overlap=64,
            separators=["\n\n", "\n", "。", " "]
        )
        chunks = splitter.split_documents(self.docs)
        return chunks
```

**三个核心参数的含义：**

**`chunk_size=512`**——每个文本块最多 512 个字符。为什么是 512？太小了语义不完整——比如"他"被切出来，你不知道"他"是谁。太大了超出了 embedding 模型的输入限制，被截断的部分直接丢弃，等于白切。512 是中文场景一个经验值，差不多两三段话，语义足够但又不会过长。

**`chunk_overlap=64`**——相邻两个块之间重叠 64 个字符。为什么需要重叠？假设有句话正好卡在切割点上，前半句在 A 块、后半句在 B 块，两个块都没法独立理解这句话。重叠 64 个字符等于加了个缓冲区，关键信息不会因为切分位置而丢失。但也不能太大——overlap 太大了会导致同一条信息在多个块里重复出现，浪费存储不说，检索时还会干扰排序。

**`separators`**——切割优先级。它不是简单粗暴地数 512 个字符就切，而是先尝试在"双换行"处切（段落边界），不行再尝试"单换行"（行边界），再不行用"句号"（句子边界），最后才是空格。这样切出来的块尽可能地是语义完整的段落，而不是从半句话中间断开。

**为什么叫 `RecursiveCharacterTextSplitter`？**

"Recursive"指的是递归试切。它先拿第一个分隔符 `\n\n` 去切全文。切完后检查每段长度，超过 512 的拿第二个分隔符 `\n` 再切一次，还超就换 `。`，以此类推。这保证了只要文本本身有段落结构，切割永远优先顺着结构走，而不是硬截断。

---

### 4.3 向量索引 `loader/document_index.py`

```python
class DocumentIndex:
    def __init__(self, chunks, vectorstore, delete_flag=False):
        self.chunks = chunks
        self.vectorstore = vectorstore
        self.delete_flag = delete_flag

    def delete_vectors(self):
        ids = self.vectorstore.get()["ids"]
        if len(ids) > 0:
            self.vectorstore.delete(ids=ids)

    def add_documents(self):
        if self.delete_flag:
            self.delete_vectors()
        self.vectorstore.add_documents(self.chunks)
```

**为什么 `add_documents` 之前要判断 `delete_flag`？**

这就是你之前担心的问题——重复添加导致数据膨胀。`delete_flag=True` 时，先调用 `delete_vectors()` 把当前 collection 里所有向量清空，再写入新的。`delete_flag=False` 时不清理，直接在末尾追加，适合增量更新场景。

具体到你之前担心的场景：你跑了一遍入库，又跑了一遍，collection 里就有两份一模一样的数据。检索时两个结果分数相同，白白浪费候选名额。所以重建索引时一定设 `delete_flag=True`。

**`vectorstore.add_documents(chunks)` 内部做了什么？**

对你来说就是一行调用，但实际上它做了三步：先拿 embedding 模型把每个 chunk 转成 768 维向量，再生成唯一 ID，最后连同原始文本和元数据一起写入 Chroma。LangChain 把这个过程封装了，你不需要手动调 embedding 模型。

---

### 4.4 流程编排 `loader/vector_index.py`

```python
def create_vector_index(file_path: str, delete_flag: bool = False):
    document_loader = DocumentLoader(file_path=file_path)
    docs = document_loader.loader()

    document_splitter = DocumentSplitter(docs=docs)
    chunks = document_splitter.split()

    document_index = DocumentIndex(chunks, vectorstore=vectorstore, delete_flag=delete_flag)
    document_index.add_documents()
```

**这个文件的意义是什么？**

前面三个类每个只做一件事，符合单一职责原则。但当上层调用时，它不应该关心"先调哪个后调哪个"——这个顺序是固定的，应该封装起来。`create_vector_index` 就是流水线的总控开关，外部只需传一个文件路径，它按顺序走完加载→切割→入库，返回时数据已经在 Chroma 里了。

注意它没返回值。入库是副作用操作——数据写进了 Chroma，函数不需要返回什么东西。这和 `loader()` 返回 `docs`、`split()` 返回 `chunks` 不同，它们是无副作用的纯函数。

---

三个环节连起来就是：DocumentLoader 把物理文件变成 Document 对象 → DocumentSplitter 把长 Document 切成短 chunk → DocumentIndex 把 chunk 向量化后写入数据库。每一步的输入输出类型一致，所以能像水管一样一根接一根。

---

## 第五步：检索层 `retriever/`

入库那条链路跑完了，数据已经在 Chroma 里了。现在来处理问答链路——用户提一个问题，怎么从向量库里捞出最相关的文档片段。

### 5.1 向量检索 `retriever/retriever.py`

```python
from rag_demo.models.chroma import vectorstore

class VectorRetriever:
    def __init__(self, vectorstore):
        self.vectorstore = vectorstore

    def vector_retrieve(self, query):
        retriever = self.vectorstore.as_retriever(
            search_type="similarity_score_threshold",
            search_kwargs={
                "score_threshold": 0.5,
                "k": 10
            }
        )
        return retriever.invoke(query)

    def get_retriever(self):
        return self.vectorstore.as_retriever(
            search_type="similarity_score_threshold",
            search_kwargs={
                "score_threshold": 0.5,
                "k": 10
            }
        )
```

**`search_type="similarity_score_threshold"` 做了什么？**

Chroma 检索有三种模式：`similarity` 只按分数从高到低排，`mmr` 在相关性之外还考虑多样性（避免结果太雷同），`similarity_score_threshold` 在排序基础上加了一个门槛——分数低于 0.5 的直接丢弃。

为什么选第三种？RAG 场景里用户可能问一个知识库里完全没有的话题。如果不用阈值，这时候 Chroma 也会硬塞 10 条"最相关的"，但它们跟问题八竿子打不着。LLM 拿到一堆不相关的上下文，要么乱编，要么触发幻听式的拒绝回答。加了 0.5 的阈值，如果库里的内容跟问题没有半毛钱关系，就直接返回空列表，后面的流程能感知到"我没找到相关内容"。

**为什么 k=10 而不是直接取 k=5？**

这里取 10 是为了给下一步重排留余地。向量检索是粗筛——用 embedding 模型把问题和文档都变成向量后算余弦相似度，速度快但精度有限，因为把一个几百字的段落压缩成 768 个数字本身就会丢失信息。多捞几条（10 条），下一步用更精确的重排模型从这 10 条里再挑出最相关的 5 条，准确率会高很多。

**`get_retriever` 和 `vector_retrieve` 为什么要分两个方法？**

`get_retriever` 返回的是 `retriever` 对象本身，不是一个结果列表。它给 `reranker.py` 里的 `ContextualCompressionRetriever` 用——那个类需要接收一个 retriever 对象作为参数，内部自己调 `invoke`。而 `vector_retrieve` 是对外直接用的，返回结果列表。两个方法面对不同的调用方，不能合并成一个。

---

### 5.2 重排器 `retriever/reranker.py`

```python
from langchain.retrievers import ContextualCompressionRetriever
from langchain.retrievers.document_compressors import CrossEncoderReranker
from langchain_community.cross_encoders import HuggingFaceCrossEncoder

from rag_demo.models.chroma import vectorstore
from rag_demo.retriever.retriever import VectorRetriever

class CompressReranker:
    def __init__(self, cross_encoder_name):
        self.cross_encoder_name = cross_encoder_name

    def _get_reranker(self):
        cross_encoder = HuggingFaceCrossEncoder(
            model_name=self.cross_encoder_name,
            model_kwargs={"device": "cpu"},
        )
        return CrossEncoderReranker(model=cross_encoder, top_n=5)

    def ranker(self, query):
        reranker = self._get_reranker()

        retriever_clz = VectorRetriever(vectorstore)
        retriever = retriever_clz.get_retriever()

        compression_retriever = ContextualCompressionRetriever(
            base_compressor=reranker,
            base_retriever=retriever
        )
        compressed_docs = compression_retriever.invoke(query)
        return compressed_docs
```

**为什么需要重排这个额外步骤？前面向量检索不是已经排序了吗？**

这是整个 RAG 系统里最重要但也最容易被新手跳过的环节。两个模型的原理完全不同：

向量检索用的是 bi-encoder——问题和文档分别独立编码成向量，然后算向量之间的距离。速度快，但是"分别独立"意味着编码时问题看不到文档、文档也看不到问题，只能靠向量空间里"尽量近"来猜测相关性。

交叉编码器（cross-encoder）不同。它把问题和候选文档拼成一对，同时输入一个 Transformer 模型，模型内部多层注意力机制让文档的每个词都能看到问题的每个词，输出的分数是这一对"真正有多相关"的判断。慢一些，但准得多。

一个比喻：向量检索像你走进图书馆，管理员看了一眼你的借阅记录，指了指"历史区第三排"——快，但可能指错位置。交叉编码器像是你把要查的问题念给管理员听，他翻了三四本书的内容才给你答案——慢，但准。

**`top_n=5` 的设计逻辑？**

前面向量检索取了 10 条，重排后只保留 5 条。这 5 条塞进 LLM 的上下文窗口刚刚好——太少可能漏掉关键信息，太多会超出 token 限制或者稀释了重要内容。RAG 里有个经验：给 LLM 的上下文不是越多越好，5 条高质量片段远胜 20 条中等质量的。

**`ContextualCompressionRetriever` 的命名为什么带 Compression？**

LangChain 把重排抽象为一种"压缩"操作——输入一堆文档，输出更少但更相关的一小撮。`base_compressor` 做压缩，`base_retriever` 提供待压缩的候选池，两者拼成一条流水线。

---

### 5.3 上下文生成器 `retriever/chat_generator.py`

```python
import os
from rag_demo.retriever.reranker import CompressReranker

HF_HOME = os.getenv("HF_HOME", "")
RERANKER_MODEL_DIR = os.path.join(HF_HOME, "hub", "models--BAAI--bge-reranker-base")

class ChatGenerator:
    def get_context(self, query):
        compress_ranker = CompressReranker(cross_encoder_name=RERANKER_MODEL_DIR)
        chunks = compress_ranker.ranker(query)
        context = "\n\n".join([doc.page_content for doc in chunks])
        return context
```

**这个类的存在价值是什么？**

它把前面所有检索逻辑打包成一个方法 `get_context(query)`。上层调用者只需要传一个问题字符串，拿到一个上下文字符串，完全不需要知道中间经历了向量检索、交叉编码器重排、结果拼接。

这就是外观模式（Facade）的思想——复杂流程被封在门后，露出的接口极其简单。后面 API 层调用 `ChatGenerator.get_context("原神里钟离是谁")` 就完事了。

**`"\n\n".join` 做了什么？**

重排返回的不是字符串，是 `List[Document]` 对象列表。每个 `Document` 的 `page_content` 包含那段文本。`"\n\n"` 把多个片段用两个换行拼接，让 LLM 能看清片段之间的边界，知道这是来自文档不同位置的内容，不会把它们当成一段连续的文字来理解。

---

检索层到这里就结束了。一条线是向量检索（广撒网）→ 重排（精筛选）→ 上下文拼接，三个模块层层递进。

---

## 第六步：API 层 `api/`

前面所有的代码都在"搭积木"——加载、切割、入库、检索、重排、LLM。但它们只是在 Python 里可用，没有对外暴露。API 层就是给这些能力装上"门把手"，让外部能通过 HTTP 请求来调用。

### 6.1 统一响应体 `api/response.py`

```python
from pydantic import BaseModel

class ApiResponse(BaseModel):
    code: int
    msg: str
    data: Any | None = None
```

**为什么开篇就写这个，而不是直接写路由？**

FastAPI 依赖 Pydantic 做数据校验和序列化。如果你的每个接口返回格式不同——有的返回 `{"status": "ok"}`、有的返回 `{"error_code": 500}`——前端就得写多套解析逻辑。先约定一个统一格式 `{code, msg, data}`，所有接口都用它包裹返回，前端只用一套解析。

`BaseModel` 是 Pydantic 的核心类。继承它之后，FastAPI 会自动对 `data` 字段做 JSON 序列化，你在代码里放一个 `Document` 对象，返回给用户时自动变成 JSON 字符串，不用手动 `json.dumps`。

**`Any | None = None` 是什么意思？**

`data` 可能为空（比如删数据不需要返回内容），也可能为任意类型（列表、字典、字符串）。`Any | None` 告诉类型检查器：这个字段可以不传，传了也不限定类型。`= None` 是默认值，调用方不填 `data` 时不会报错。

---

### 6.2 文件上传接口 `api/file_upload_router.py`

```python
from fastapi import APIRouter, UploadFile, File
from rag_demo.api.response import ApiResponse
from rag_demo.loader.vector_index import create_vector_index

file_upload_router = APIRouter(prefix="/admin")

@file_upload_router.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    try:
        file_name = file.filename
        dir_path = "tmp_upload"
        os.makedirs(dir_path, exist_ok=True)

        content = await file.read()
        file_path = os.path.join(dir_path, file_name)
        with open(file_path, "wb") as f:
            f.write(content)

        create_vector_index(file_path=file_path)
        return ApiResponse(code=200, msg="上传文件，创建向量索引成功", data=None)
    except Exception as e:
        raise Exception("上传文件，创建向量索引失败", e)
```

**为什么要先把文件存到磁盘再处理，而不是直接传到索引？**

两个原因。第一，`DocumentLoader` 的所有加载器都接受文件路径作为参数，它们内部会自己 `open()` 文件，不能直接吃内存里的东西。第二，存到 `tmp_upload` 后，如果入库失败，你还有原始文件可以重试。直接扔进处理流程，失败了什么都没留下。

**为什么是 `async def`？**

FastAPI 天然支持异步。`await file.read()` 这句在读取用户上传的文件时，不会阻塞整个服务器——其他请求仍然能被处理。如果写成同步 `def`，文件上传期间整个线程卡住，其他人访问就排队等。对于 I/O 密集型操作（文件读写、网络请求），异步能大幅提升并发能力。

**`prefix="/admin"` 的含义？**

这个接口是管理端用的——上传文件、建索引——不是给普通用户用的。加 `/admin` 前缀一来语义清晰，二来后续如果加身份鉴权，可以直接在 `/admin` 这个前缀上统一拦截，而不需要在每个 `/admin` 下的接口里单独写。

---

### 6.3 对话接口 `api/chat_router.py`

```python
from fastapi import APIRouter, Query
from langchain_core.prompts import ChatPromptTemplate
from starlette.responses import StreamingResponse

from rag_demo.models.llm import qwen_llm
from rag_demo.retriever.chat_generator import ChatGenerator

chat_router = APIRouter(prefix="/chat")

async def _generator(query):
    chat_generator = ChatGenerator()
    context = chat_generator.get_context(query)

    prompt_template = ChatPromptTemplate.from_messages([
        ("system", "你是一个有帮助的助手，基于提供的上下文信息回答问题。"),
        ("human", """你是一位知识助手，请根据用户的问题和下列片段生成准确的回答。
                用户问题: {question}
                相关片段:
                {context}
                请基于上述内容作答，不要编造信息。""")
    ])

    chain = prompt_template | qwen_llm
    async for chunk in chain.astream({"question": query, "context": context}):
        if hasattr(chunk, "content"):
            yield chunk.content
        else:
            yield str(chunk)

@chat_router.get("/ask")
async def ask(query: str = Query(..., description="用户问题")):
    return StreamingResponse(_generator(query), media_type="text/event-stream")
```

**这个文件是整个 RAG 链路的总装车间。从头拆解每一步：**

**第一步：获取上下文。** `ChatGenerator.get_context(query)` 触发整个检索链路——向量检索取 10 条 → 交叉编码器重排取 5 条 → 拼接成字符串。这一步耗时最长，因为要调 embedding 模型和 reranker 模型两个本地推理，但只需做一次。

**第二步：构建提示词模板。** `ChatPromptTemplate.from_messages` 定义了两个角色：`system` 和 `human`。`system` 是全局指令，设定模型的角色——"基于上下文回答问题"。`human` 是具体任务，把问题 `{question}` 和上下文 `{context}` 作为变量注入。

**为什么 system 和 human 要分开？**

不同模型对这两个角色的处理不同。通义千问会用 system 里的指令约束整个回答的风格和边界，用 human 里的具体内容来生成回答。分开写确保指令不会跟用户内容混在一起被误解。如果全部塞进 human 里，模型可能在回答中途"忘掉"指令。

**第三步：`prompt_template | qwen_llm` 这个管道符号是什么意思？**

这是 LangChain 的 LCEL（LangChain Expression Language），用 `|` 连接组件形成处理链。`prompt_template | qwen_llm` 等价于"先把变量填进模板生成完整 prompt，再把 prompt 送给 LLM"。如果你有多个步骤，可以无限接下去：`component_a | component_b | component_c`。

**第四步：流式输出 `chain.astream()`。** `astream` 不是等到 LLM 生成完再一次性返回，而是每生成一个 token 就 yield 出去。对用户体验来说，这意味着页面上的文字一个字一个字往外蹦，而不是等 5 秒突然弹出一大段——感知延迟大幅降低。

`hasattr(chunk, "content")` 这个判断是因为 LangChain 的流式 chunk 有时是纯字符串，有时是带属性的对象，做了个兼容处理。

**第五步：`StreamingResponse`。** FastAPI 的 `StreamingResponse` 支持 Server-Sent Events（SSE）协议。浏览器或客户端收到第一个字符后就能开始渲染，不用等整个响应结束。`media_type="text/event-stream"` 告诉浏览器这是流式数据。

---

### 6.4 入口文件 `main.py`

```python
from fastapi import FastAPI
from rag_demo.api.chat_router import chat_router
from rag_demo.api.file_upload_router import file_upload_router

app = FastAPI()
app.include_router(file_upload_router, prefix="/api")
app.include_router(chat_router, prefix="/api")
```

**为什么还要加一层 `/api` 前缀？**

每个路由自己都带了前缀（`/admin`、`/chat`），但 entry point 再加 `/api`，最终路径变成 `/api/admin/upload` 和 `/api/chat/ask`。这样做的好处是：如果以后前端挂在同一个域名下，Nginx 可以把 `/api/*` 全部转发到 FastAPI， `/` 走前端静态资源，互不干扰。

**为什么 `import` 写在文件顶部但不会触发入库？**

`from rag_demo.api.chat_router import chat_router` 这个 import 会执行 `chat_router.py` 里的顶层代码，包括 import `ChatGenerator`。但因为 `ChatGenerator` 的构造方法里没有做任何耗时操作（模型在真正调用 `get_context` 时才加载），所以 import 本身是瞬时的。这是一个重要的设计原则——模块导入时不应产生副作用。

---

API 层结束。整个项目的完整调用流程：

```
用户上传文件 → POST /api/admin/upload
  → 存临时文件 → create_vector_index
    → DocumentLoader 加载
    → DocumentSplitter 切割 (512字/块, 重叠64字)
    → DocumentIndex 向量化写入 Chroma (collection: rag_demo)

用户提问 → GET /api/chat/ask?query=xxx
  → ChatGenerator.get_context
    → VectorRetriever 检索 (阈值0.5, top-10)
    → CrossEncoderReranker 重排 (top-5)
    → 拼接为上下文字符串
  → ChatPromptTemplate 注入提示词
  → 通义千问流式生成
  → SSE 逐字返回
```

---

## 第七步：收尾工作

### 7.1 日志 `utils/logger.py`

```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("rag_demo.log", encoding="utf-8")
    ]
)

logger = logging.getLogger("rag_demo")
```

**三个设计点：**

**`basicConfig` 只调一次**——`logging.basicConfig` 在 Python 进程生命周期里只有第一次调用有效。所以必须放在一个独立的、会最先被 import 的模块里。如果散落在各个文件里各自调一次，只有最早执行的那个生效，后面的全被忽略。

**双输出——控制台 + 文件**——`StreamHandler()` 写到终端，开发调试时实时看到。`FileHandler("rag_demo.log")` 写到文件，线上出问题时能翻历史日志查找线索。两者并存，互不替代。

**`encoding="utf-8"` 不能省**——Windows 下文件写入默认编码可能不是 UTF-8。你的知识库全是中文内容，不加这个参数的话，日志里中文字符全变乱码，完全不可读。

**但说实话，这个 logger 在整个项目里用得不多。** 它目前是个"占位"——留着当以后加了 try/except 需要记录异常、或者想统计查询耗时的时候，不用从头搭。一个项目的工具层往往都是这样，先预留，用到时再扩展。

---

### 7.2 环境变量 `.env`

```
QWEN_MODEL_NAME=qwen-turbo
QWEN_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
QWEN_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
```

**必须配套 `.gitignore`**，至少要包含：

```
.env
rag_demo.log
tmp_upload/
__pycache__/
*.pyc
```

`.env` 里有 API Key，绝对不能进版本控制。`tmp_upload/` 是用户上传的临时文件，也不该提交。`__pycache__/` 是 Python 自动生成的编译缓存，跟项目无关。

---

### 7.3 启动命令

```cmd
uvicorn rag_demo.main:app --host 0.0.0.0 --port 8000 --reload
```

**逐参数解释：**

**`rag_demo.main:app`**——`rag_demo.main` 是 Python 模块路径（对应 `rag_demo/main.py`），`:app` 是该模块里 FastAPI 的实例变量名。Uvicorn 会找到这个对象并启动 ASGI 服务器。

**`--host 0.0.0.0`**——监听所有网络接口。如果写 `127.0.0.1`，只能本机访问。写 `0.0.0.0` 后局域网其他设备也能访问（比如手机测试）。生产环境下通常前面会挂 Nginx，只暴露 127.0.0.1。

**`--port 8000`**——FastAPI 应用端口。注意跟 Chroma 的 8081 区分开，两者互不冲突——Chroma 是数据库服务，FastAPI 是应用服务，各自独立监听。

**`--reload`**——开发模式，代码改动后自动重启。线上部署时要去掉这个参数，否则每次文件变更都重启会导致服务不稳定。

---

### 7.4 完整项目文件清单

最终整个项目的文件树：

```
rag_demo/
├── main.py
├── .env                        # 不提交
├── .gitignore
├── api/
│   ├── __init__.py
│   ├── chat_router.py
│   ├── file_upload_router.py
│   └── response.py
├── models/
│   ├── __init__.py
│   ├── chroma.py
│   └── llm.py
├── loader/
│   ├── __init__.py
│   ├── document_loader.py
│   ├── document_splitter.py
│   ├── document_index.py
│   └── vector_index.py
├── retriever/
│   ├── __init__.py
│   ├── retriever.py
│   ├── reranker.py
│   └── chat_generator.py
└── utils/
    ├── __init__.py
    ├── config.py
    └── logger.py
```

16 个模块，每个职责单一，从外到内一共四层：API 接请求 → Retriever 检索上下文 → Loader 管理文档 → Models 提供基础设施。改任何一层不会波及其他层，这就是整个项目的设计哲学。
