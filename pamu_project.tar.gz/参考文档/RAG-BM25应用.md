基于文档内容和最新行业实践，我来系统讲解 BM25 在 RAG 中的实现与应用。

一、为什么 RAG 需要 BM25？

纯向量检索有两个结构性短板：

短板 具体表现

精确匹配失败 产品型号、错误码、API名称、条款编号等精确 token，向量检索经常"视而不见"

罕见词坍塌 低频词（如 ICD-10 编码、RFC 编号）在 embedding 空间中趋于相似，无法区分

社区实测数据参考（注意：绝对数值与场景强相关，以下为多个独立实验的趋势汇总，不可当作通用基准）：纯向量检索 Hit Rate 约 67%~82%，纯 BM25 约 65%~78%，混合后约 78%~91%。提升幅度在 10~15 个百分点区间，具体取决于文档类型和查询特征。

核心洞察：BM25 和向量检索"失败的方向相反"——向量漏掉的精确词，BM25 能捡回来；BM25 漏掉的语义改写，向量能补上。

二、整体架构：四阶段流水线

业界公认的生产级 RAG 检索架构是 "铁三角"：

用户查询
  ├── BM25 稀疏检索 ──→ Top-50 候选
  └── 向量稠密检索 ──→ Top-50 候选
              ↓
      RRF 融合（合并排名）
              ↓
      Cross-Encoder 精排（Top-50 → Top-10）
              ↓
      LLM 生成答案（带引用）


每一步的职责：

阶段 作用 延迟

BM25 召回 精确关键词命中 <10ms

向量召回 语义理解、模糊匹配 10~50ms

RRF 融合 合并两路排名，消除分数尺度差异 +6ms

Cross-Encoder 精排 逐对精算 query-document 相关性 50~200ms

三、关键实现细节

1. BM25 的实现方式（三种选型）

文档中介绍了三种方案，结合行业实践整理对比如下：

方案 适用场景 优点 缺点

rank_bm25（轻量库） 原型验证、中小规模（<10万文档） 纯 Python、无外部依赖、可控性强 不支持持久化，重启需重建索引

BM25Retriever（LangChain 封装） 快速搭建、教学演示 API 简洁，几行代码搞定 同上，无原生持久化；中文需手动 jieba 分词

Elasticsearch / OpenSearch 生产环境、海量数据 原生 BM25、分布式、支持 IK 中文分词、支持 RRF 运维成本高

中文分词的坑（文档中重点强调）：

BM25Retriever 默认按空格分词。中文句子没有空格，整个句子会被当成一个词，导致检索完全失效。

解决方案：用 jieba.cut() 先分词，再用空格拼接成字符串喂给检索器：
import jieba
from langchain_community.retrievers import BM25Retriever

# 原始文档
docs = ["苹果公司发布新款iPhone", "华为手机采用麒麟芯片"]

# 分词后用空格连接 ← 关键步骤！
tokenized = [" ".join(jieba.cut(d)) for d in docs]
# → ["苹果 公司 发布 新款 iPhone", "华为 手机 采用 麒麟 芯片"]

retriever = BM25Retriever.from_texts(tokenized, k=2)


2. 分数融合：为什么不能直接加分？

这是最容易踩的坑。文档和业界都强调：

BM25 分数和向量相似度不在同一个度量空间，直接加权相加是错的。

原因：
• BM25 无上限：命中词越多分数越高，可能达到几十甚至上百

• 向量余弦相似度有界：严格在 [-1, 1] 或 [0, 1] 区间

直接加权的后果：BM25 的量级碾压向量分数，向量那一路形同虚设。

3. RRF（Reciprocal Rank Fusion）：生产首选

RRF 完全不看分数，只看排名，公式极简：

RRF\_score(d) = \sum_{r \in Ranks} \frac{1}{k + rank_r(d)}

其中 k 通常取 60。

Python 实现：
def rrf_fusion(bm25_results, vector_results, k=60, top_n=10):
    scores = {}
    # BM25 路贡献
    for rank, doc_id in enumerate(bm25_results, 1):
        scores[doc_id] = scores.get(doc_id, 0) + 1 / (k + rank)
    # 向量路贡献
    for rank, doc_id in enumerate(vector_results, 1):
        scores[doc_id] = scores.get(doc_id, 0) + 1 / (k + rank)
    # 按 RRF 分数排序
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_n]


RRF 的优势：
• 对分数尺度完全免疫（不管 BM25 是 12.5 还是 0.01，只看排名）

• 无需调参，开箱即用

• 几行代码即可实现

4. 加权融合（有标注数据时更优）

当你有标注数据（golden set）时，归一化后加权可以超越 RRF：
import numpy as np

def minmax_normalize(scores):
    """Min-Max 归一化到 [0, 1]"""
    s = np.array(scores)
    return (s - s.min()) / (s.max() - s.min() + 1e-9)

# 加权融合（仅在有标注数据做网格搜索时才值得使用）
# 以下权重仅为示意，实际场景差异极大，不可直接套用
final_score = 0.6 * vector_norm + 0.4 * bm25_norm

# 生产建议：先跑通无加权的 RRF 基线，效果不够再考虑加权
# 加权融合需要标注评估集做网格搜索，否则权重是拍脑袋的

5. 精排：Cross-Encoder Reranker

融合后的候选集（通常 Top-30~50）再送进 Cross-Encoder 做精排：

• 原理：将 query 和 document 拼接后一起过 Transformer，逐对计算相关性分数

• 效果：比 Bi-Encoder（独立编码）精度高得多

• 常用模型：BAAI/bge-reranker-v2-m3（中文首选，支持多语言）、BAAI/bge-reranker-base（110M 参数，轻量备选）
  注意：cross-encoder/ms-marco-MiniLM-L-6-v2 是英文数据集训练，中文场景效果差，不应使用

关键约束：精排必须限定在小范围候选集上。全库精排延迟会从 200ms 飙到 3 秒。

四、Query 路由：可选优化，非标配

比固定权重更精细的方案是按 Query 类型动态路由。注意：这是进阶优化手段，不是生产环境的标配。绝大多数场景下，两路并行检索 + RRF 自动融合已经足够好，路由只在效果瓶颈明确指向某类查询时才值得引入。

Query 类型 示例 应主导的路 判断信号

精确标识符 "ERR-4042"、"v2.3.1" BM25 正则匹配 ID/错误码/版本号格式

领域专名 "K8s 节点漂移" BM25 命中领域词典

短查询 "线程池" BM25 长度 < 5 词，向量区分度差

自然语言 "为什么订单创建后库存没扣减？" 向量 含疑问句特征（为什么/怎么/如何）

混合型 "ERR-500 是什么原因？" 平衡 既有硬 token 又有语义描述

实现方式：轻量分类器（规则 + 词典即可覆盖大多数场景），无需训练模型。

五、完整代码骨架（LangChain 生态）

结合文档中的代码示例，给出可运行的生产级骨架：
import jieba
from langchain_community.retrievers import BM25Retriever
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings
from langchain_core.documents import Document
from sentence_transformers import CrossEncoder

# ========== 1. 文档准备：为每篇文档分配唯一 ID ==========
# ★ 关键：必须为每篇文档预先分配唯一 ID，存入 metadata
# 不能用 Python id() 做融合去重——同一内容在两路是不同的 Python 对象，
# id() 返回内存地址，必然不同，RRF 无法合并排名
raw_texts = ["苹果公司发布新款iPhone", "华为手机采用麒麟芯片", ...]

raw_docs = []
tokenized_docs = []
for i, text in enumerate(raw_texts):
    doc_id = f"doc_{i}"  # 生产环境建议用 uuid 或业务 ID
    raw_docs.append(Document(page_content=text, metadata={"doc_id": doc_id}))
    tokenized_docs.append(
        Document(page_content=" ".join(jieba.cut(text)), metadata={"doc_id": doc_id})
    )

# 构建 doc_id → Document 的映射，供 RRF 融合后还原
doc_map = {doc.metadata["doc_id"]: doc for doc in raw_docs}

# ========== 2. 双路检索器 ==========
# BM25 路（用分词后的文档）
bm25 = BM25Retriever.from_documents(tokenized_docs, k=50)

# 向量路（用原始文档，语义编码更完整）
embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
vectorstore = Chroma.from_documents(raw_docs, embeddings)
vector_ret = vectorstore.as_retriever(search_kwargs={"k": 50})

# ========== 3. 混合检索 + RRF 融合 ==========
def hybrid_search(query, top_n=30):
    q = " ".join(jieba.cut(query))
    bm25_results = bm25.invoke(q)    # List[Document]
    vector_results = vector_ret.invoke(query)
    
    # RRF 融合：用 metadata["doc_id"] 作为去重 key
    scores = {}
    for rank, doc in enumerate(bm25_results, 1):
        did = doc.metadata.get("doc_id")
        if did is None:
            continue
        scores[did] = scores.get(did, 0) + 1 / (60 + rank)
    for rank, doc in enumerate(vector_results, 1):
        did = doc.metadata.get("doc_id")
        if did is None:
            continue
        scores[did] = scores.get(did, 0) + 1 / (60 + rank)
    
    # 按 RRF 分数排序，映射回 Document
    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_n]
    return [doc_map[did] for did, _ in ranked if did in doc_map]

# ========== 4. Cross-Encoder 精排 ==========
# ★ 中文场景必须用支持中文的 Reranker，不能用 ms-marco-MiniLM
# bge-reranker-v2-m3 是社区公认的中文最佳开源选择
reranker = CrossEncoder("BAAI/bge-reranker-v2-m3")

def rerank(query, candidates, top_k=5):
    pairs = [[query, doc.page_content] for doc in candidates]
    scores = reranker.predict(pairs)
    return sorted(zip(scores, candidates), key=lambda x: x[0], reverse=True)[:top_k]

# ========== 5. 完整调用 ==========
query = "苹果手机芯片"
candidates = hybrid_search(query, top_n=30)
final_top3 = rerank(query, candidates, top_k=3)


六、一句话总结

BM25 在 RAG 中的角色是"精确匹配的兜底"：它和向量检索互补，通过 RRF 融合合并排名（避免分数尺度问题），再用 Cross-Encoder 精排提纯，最终把高质量上下文喂给 LLM。这套"BM25 + 向量 + Rerank"铁三角，是 2026 年生产级 RAG 的标配架构。