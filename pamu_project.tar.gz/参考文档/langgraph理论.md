## 12.LangGraph

LangGraph 是 LangChain 生态中用于构建复杂 AI 工作流的核心框架，它将工作流程抽象为**有向状态图（Directed State Graph）**，通过节点、边和共享状态的组合实现灵活的多步骤任务编排。

### 12.1 LangGraph核心概念

LangGraph 将工作流表示为相互连接的节点网络，每个节点对应特定函数或子任务，边则捕获节点间的逻辑和语义关系。与传统链式调用不同，这种图结构支持**条件分支、循环、并行**等复杂控制流，特别适合多 Agent 协作、长对话上下文管理等场景。

LangGraph 是 LangChain 的高级封装，复用其 LLM、Tool、Memory 等组件，但提供更强大的流程控制能力：

| 特性     | LangChain              | LangGraph                |
| :------- | :--------------------- | :----------------------- |
| 抽象单元 | Chain/Tool/Agent       | Node/State/Edge          |
| 控制流   | 顺序执行               | 状态跳转、条件分支       |
| 适用场景 | 简单问答、单次工具调用 | 多步骤工作流、Agent 协作 |

### 12.2 LangGraph 核心组件

#### 12.2.1 State（状态）- 共享内存中心

状态是贯穿整个工作流的**共享数据结构**，作为全局内存持久化存储：

- 记录工作流执行进度、中间结果、配置参数
- 所有节点可读取当前状态数据并更新
- 确保组件间无缝信息共享和执行历史可追溯

#### 12.2.2 Node（节点）

节点是工作流的基本执行单元，通常为**纯函数**，接收当前状态并返回更新后的状态片段。

节点类型：

- Action Node：执行业务逻辑（检索、工具调用等）
- LLM Node：调用大模型生成响应
- Conditional Node：根据条件路由到不同分支

#### 12.2.3 Edge（边）

边定义节点间的连接和执行顺序，分为两类：

- 普通边：确定性路由，`add_edge(from, to)`
- 条件边：动态路由，`add_conditional_edges()` 根据函数返回值决定下一步
- 入口边：`START`节点
- 出口边：`END` 节点

### 12.3 LangGraph 构建步骤

#### 12.3.1 **定义状态结构（State Schema）**

状态是整个工作流的共享内存，需用 `TypedDict` 或 Pydantic 模型精确定义。

#### 12.3.2 **设计节点函数（Node Functions）**

节点是纯函数，遵循 "读状态 → 处理 → 返回更新片段" 模式。

#### 12.3.3 **初始化 StateGraph 并添加节点**

创建图实例，注册所有节点，并配置入口点。

#### 12.3.4 **定义边关系（Edges）**

边控制执行流，分为三种类型：

类型 1：普通边（顺序执行）

类型 2：条件边（动态路由）

类型 3：循环边（返回已访问节点）

#### 12.3.5 **编译图（Compile）**

编译阶段进行拓扑排序、连通性验证、检查点配置。

#### 12.3.6 **执行工作流（Invocation）**

支持同步、异步、流式三种调用方式。

方式 1：同步调用（阻塞）

方式 2：流式输出（实时日志）

方式 3：带检查点的执行（可恢复）

通过以上六个步骤，你可以构建出从简单顺序流程到复杂多循环、条件分支、带持久化检查点的工业级工作流。关键要记住：**状态是中心、节点是纯函数、边是控制流**，三者分离才能保持架构的清晰与可维护性。

<img src="./workflow/QQ20260226-092104.png"/>

### 12.4 案例1

基本LangGraph实现案例：评估器

流程图：

<img src="D:\work\实训\项目\AI\大模型-workflow\media\QQ20251229-093716.png"/>

实现步骤：

**1.定义状态**

```python
class State(TypedDict):
    joke: str  # 冷笑话内容
    topic: str  # 用户提供的主题
    feedback: str  # 改进建议或反馈
    funny_or_not: str  # 判断冷笑话是否幽默
```

**2.定义节点函数**

案例中定义两个节点：

1.生成笑话节点

```python
def generate_func(state: State):
    """由大模型生成的一个笑话节点"""

    prompt = (
        f"根据反馈改进笑话：{state.get('feedback', None)}\n主题：{state['topic']}"
        if state.get('feedback', None)
        else f"创作一个关于{state['topic']}主题的冷笑话"
    )

    chain = llm | StrOutputParser()

    res = chain.invoke(prompt)
    print(res)
    return {'joke': res}
```

2.评估笑话节点

这里使用pydantic来定义输出类型

```python
class Feedback(BaseModel):
    # Literal[...] 表示一个变量被限定为只能取括号内指定的一个或多个具体的值，而不是任意的同类型值。
    funny_or_not: Literal['funny', 'not funny'] = Field(
        description='判断冷笑话是否幽默',
        examples=['funny', 'not funny']
    )

    feedback: str = Field(
        description='如果不幽默，则提出改进建议',
        examples=['可以添加笑料、双关语或意外结局等']
    )
    
    

def evaluate_func(state: State):
    """评估冷笑话节点"""
    parser = PydanticOutputParser(pydantic_object=Feedback)

    template = """请评估以下冷笑话的幽默程度：

    笑话内容：{joke}

    要求：
    1. 判断笑话是否幽默（选择：funny 或 not funny）
    2. 如果不幽默，请提供具体的改进建议

    {format_instructions}"""

    prompt_template = PromptTemplate(
        template=template,
        input_variables=["joke"],
        partial_variables={"format_instructions": parser.get_format_instructions()}
    )


    chain = prompt_template | llm | parser

    res = chain.invoke({'joke': state['joke']})

    return {
        'feedback': res.feedback,
        'funny_or_not': res.funny_or_not
    }
```

**3.初始化StateGraph并添加节点**

```python
builder = StateGraph(State)
# 添加节点
builder.add_node('generator', generate_func)
builder.add_node('evaluator', evaluate_func)
```

**4.定义边**

按照流程图，需要添加：

1.开始节点到生成笑话节点的普通边

2.生成笑话节点到评估笑话节点的普通边

3.在评估笑话节点需要判断：如果笑话好笑则执行到结束节点，否则返回到生成节点重新生成笑话，所以这里需要使用add_conditional_edges()函数完成，并需要定义一个路由函数来决定流向。

```python
# 条件边的路由函数
def route_func(state: State):
    """动态路由决策函数"""

    return (
        END if state['funny_or_not'] == 'funny' else 'generator'
    )


# 添加边
builder.add_edge(START, 'generator')
builder.add_edge('generator', 'evaluator')
builder.add_conditional_edges(
    'evaluator',
    route_func
)
```

**5.编译图**

```
graph = builder.compile()
```

**6.执行工作流**

在langgraph cli中执行即可。

或者手动执行：

```python
# 使用示例
if __name__ == "__main__":
    # 确保提供完整的初始状态
    initial_state = {
        'topic': '程序员',
        'joke': '',
        'feedback': '',
        'funny_or_not': ''
    }

    result = graph.invoke(initial_state)
    print(f"最终结果：{result}")
```

完整代码：

```python
from langchain_core.output_parsers import StrOutputParser, PydanticOutputParser
from langchain_core.prompts import PromptTemplate
from langgraph.constants import END, START
from langgraph.graph import StateGraph
from pydantic import BaseModel, Field
from typing_extensions import TypedDict, Literal

from src.agent.my_llm import llm


class State(TypedDict):
    joke: str  # 冷笑话内容
    topic: str  # 用户提供的主题
    feedback: str  # 改进建议或反馈
    funny_or_not: str  # 判断冷笑话是否幽默


class Feedback(BaseModel):
    # Literal[...] 表示一个变量被限定为只能取括号内指定的一个或多个具体的值，而不是任意的同类型值。
    funny_or_not: Literal['funny', 'not funny'] = Field(
        description='判断冷笑话是否幽默',
        examples=['funny', 'not funny']
    )

    feedback: str = Field(
        description='如果不幽默，则提出改进建议',
        examples=['可以添加笑料、双关语或意外结局等']
    )


def generate_func(state: State):
    """由大模型生成的一个笑话节点"""

    prompt = (
        f"根据反馈改进笑话：{state.get('feedback', None)}\n主题：{state['topic']}"
        if state.get('feedback', None)
        else f"创作一个关于{state['topic']}主题的冷笑话"
    )

    chain = llm | StrOutputParser()

    res = chain.invoke(prompt)
    print(res)
    return {'joke': res}


def evaluate_func(state: State):
    """评估冷笑话节点"""
    parser = PydanticOutputParser(pydantic_object=Feedback)

    template = """请评估以下冷笑话的幽默程度：

    笑话内容：{joke}

    要求：
    1. 判断笑话是否幽默（选择：funny 或 not funny）
    2. 如果不幽默，请提供具体的改进建议

    {format_instructions}"""

    prompt_template = PromptTemplate(
        template=template,
        input_variables=["joke"],
        partial_variables={"format_instructions": parser.get_format_instructions()}
    )

    prompt = prompt_template.format(joke='为什么程序员不喜欢大自然？因为那里有太多bug！')
    print(prompt)

    chain = prompt_template | llm | parser

    res = chain.invoke({'joke': state['joke']})

    return {
        'feedback': res.feedback,
        'funny_or_not': res.funny_or_not
    }


# 条件边的路由函数
def route_func(state: State):
    """动态路由决策函数"""

    return (
        END if state['funny_or_not'] == 'funny' else 'generator'
    )


builder = StateGraph(State)
# 添加节点
builder.add_node('generator', generate_func)
builder.add_node('evaluator', evaluate_func)
# 添加边
builder.add_edge(START, 'generator')
builder.add_edge('generator', 'evaluator')
builder.add_conditional_edges(
    'evaluator',
    route_func
)

graph = builder.compile()

# 使用示例
if __name__ == "__main__":
    # 确保提供完整的初始状态
    initial_state = {
        'topic': '程序员',
        'joke': '',
        'feedback': '',
        'funny_or_not': ''
    }

    result = graph.invoke(initial_state)
    print(f"最终结果：{result}")
```

### 12.5 LangGraph工具调用

`ToolNode` 是 **LangGraph** 中专门用于**执行工具（Tools）**的图节点。它是 LangGraph 预置的标准节点之一，用于在 Agent 工作流中调用外部工具（如搜索、计算、API 调用等）。

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  LLM Node   │ ──▶ │  ToolNode   │ ──▶ │  LLM Node   │
│  (决定调用)  │     │  (执行工具)  │     │ (处理结果)  │
└─────────────┘     └─────────────┘     └─────────────┘
        │                   │                   │
        └───────────────────┴───────────────────┘
                    (循环直到完成)
```

**ToolNode 的职责**：

1. 接收 LLM 生成的工具调用请求（`ToolCall`）
2. 解析要调用的工具名称和参数
3. 执行对应的工具函数
4. 将执行结果封装为 `ToolMessage` 返回

工作原理（参考ToolNode源码）：

1. ToolNode 期望从 State 中读取 `messages`，并找到最后一条 **AIMessage** 中的 `tool_calls`
2. ToolNode 返回 `ToolMessage`（会被添加到 State 的 messages 中）
3. ToolNode 会自动捕获工具异常并包装为错误消息
4. 如果 LLM 一次请求调用多个工具（如同时查天气和计算），ToolNode 会**并行执行**



`tools_condition` 是一个**预置的条件函数**，用于判断 LLM 的最后一条消息是否包含工具调用（`tool_calls`），从而决定工作流走向：

- 如果包含 `tool_calls` → 返回 `"tools"`（进入 ToolNode）
- 如果不包含 → 返回 `"__end__"`（结束工作流）

`tools_condition`源码逻辑：

```python
# 简化版逻辑（来自 langgraph.prebuilt）
def tools_condition(state: MessagesState) -> Literal["tools", "__end__"]:
    """Use in the conditional_edge to determine if we should call tools."""
    messages = state.get("messages", [])
    if not messages:
        return "__end__"
    
    last_message = messages[-1]
    
    # 检查最后一条消息是否是 AIMessage 且有 tool_calls
    if hasattr(last_message, "tool_calls") and len(last_message.tool_calls) > 0:
        return "tools"
    
    return "__end__"
```

注意：tools_condition返回的结果为"tools"或`"__end__"`，在定义工具节点时需要将节点名称固定为"tools"，否则会找不到工具节点报错。



`ToolNode`和`tools_condition`通常**成对使用**：

- `ToolNode` 负责"做"（执行工具）
- `tools_condition` 负责"判"（决定是否去 ToolNode）

这是 LangGraph **预构建（prebuilt）**模块提供的标准化模式，让 Agent 循环代码更加简洁规范。





`bind_tools` 是一个**模型绑定方法**，它将工具（Tools）的**元数据**（名称、描述、参数结构）注入到语言模型中，使模型能够**理解**、**选择**并**格式化**调用这些工具。

**`bind_tools` 的核心作用**：将工具**描述（名称、参数、文档）**注入到 LLM 的系统提示中，让模型理解：

- 有哪些工具可用
- 每个工具的功能（通过 `@tool` 装饰器的 docstring）
- 每个工具需要什么参数

底层原理：

```python
# bind_tools 实际上修改了模型的 invocation_params
model.bind_tools(tools)

# 等同于（以 OpenAI 为例）：
openai_api_call(
    model="gpt-4",
    messages=[...],
    tools=[  # ← 这是 bind_tools 注入的
        {
            "type": "function",
            "function": {
                "name": "search_weather",
                "description": "查询指定城市的天气",  # 来自 @tool 的 docstring
                "parameters": {
                    "type": "object",
                    "properties": {
                        "city": {"type": "string", "description": "城市名称"}
                    },
                    "required": ["city"]
                }
            }
        }
    ],
    tool_choice="auto"  # 让模型决定是否调用
)
```

示例1：workflow调用自定义工具

1.定义工具

```python
from langchain_core.tools import tool

@tool
def search_weather(city: str) -> str:
    """查询指定城市的天气"""
    return f"{city}今天晴天，25°C"

@tool  
def calculator(expression: str) -> str:
    """计算数学表达式"""
    return str(eval(expression))
```

2.创建ToolNode

```python
from langgraph.prebuilt import ToolNode

from src.tools import search_weather, calculator

# 方式一：直接传入工具列表
tools = [search_weather, calculator]
tool_node = ToolNode(tools)

# 方式二：传入工具名称到函数的映射
# tool_node = ToolNode({
#     "search_weather": search_weather,
#     "calculator": calculator
# })
```

3.在StateGraph中使用

```python
from langchain_core.prompts import ChatPromptTemplate
from langgraph.constants import END, START
from langgraph.graph import StateGraph, MessagesState
from langgraph.prebuilt import ToolNode, tools_condition

from src.models import qwen_llm
from src.tools import search_weather, calculator

# 方式一：直接传入工具列表
tools = [search_weather, calculator]
tool_node = ToolNode(tools)

# 方式二：传入工具名称到函数的映射
# tool_node = ToolNode({
#     "search_weather": search_weather,
#     "calculator": calculator
# })

llm_with_tools = qwen_llm.bind_tools(tools)

# 创建Graph
graph = StateGraph(MessagesState)


# 创建模型节点
def chatbot(state: MessagesState):
    """大模型节点"""

    return {"messages": llm_with_tools.invoke(state["messages"])}


# 添加节点
graph.add_node("chatbot", chatbot)
graph.add_node("tools", tool_node)

# 添加边
graph.add_edge(START, "chatbot")
graph.add_edge("tools", "chatbot")

graph.add_conditional_edges(
    "chatbot",
    tools_condition,
    {"tools": "tools", END: END}
)

# 编译
agent = graph.compile()

prompt_template = ChatPromptTemplate.from_template("用户问题：{question}")

chain = prompt_template | agent

results = chain.invoke({"question": "今天成都的天气怎么样?"})
for result in results["messages"]:
    result.pretty_print()

```

